import React, { useEffect, useState, useRef } from 'react';
import { 
  ChevronDown, 
  Star, 
  Shield, 
  Zap, 
  TrendingUp, 
  Users, 
  CreditCard, 
  CheckCircle,
  ArrowRight,
  Menu,
  X,
  Play,
  Award,
  Globe,
  Lock
} from 'lucide-react';

// Custom hook for intersection observer
const useIntersectionObserver = (options = {}) => {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting);
    }, options);

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [options]);

  return [ref, isIntersecting];
};

// Animation component
const FadeInUp = ({ children, delay = 0, className = "" }) => {
  const [ref, isIntersecting] = useIntersectionObserver({
    threshold: 0.1,
    rootMargin: '50px'
  });

  return (
    <div
      ref={ref}
      className={`transform transition-all duration-[560ms] cubic-bezier(.22,.9,.26,1) ${
        isIntersecting 
          ? 'translate-y-0 opacity-100' 
          : 'translate-y-8 opacity-0'
      } ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTestVariant, setActiveTestVariant] = useState('A'); // A/B test state
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // A/B Test Hero Variants
  const heroVariants = {
    A: {
      headline: "India's Premier Luxury B2B Marketplace",
      subheadline: "Connect with verified luxury manufacturers. Access credit-backed inventory. Scale your premium retail business with confidence.",
      cta: "Start Your Journey"
    },
    B: {
      headline: "Credit-Powered Luxury Trade Platform",
      subheadline: "Revolutionary inventory financing meets premium B2B marketplace. Transform how you source and sell luxury goods in India.",
      cta: "Unlock Credit Access"
    }
  };

  const currentHero = heroVariants[activeTestVariant];

  return (
    <div className="min-h-screen bg-[#08070A] text-[#ECE8E3] font-['Inter'] antialiased">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrollY > 50 ? 'bg-[#08070A]/95 backdrop-blur-lg border-b border-[#ECE8E3]/10' : 'bg-transparent'
      }`}>
        <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-[#D4AF37] to-[#FFD777] rounded-lg flex items-center justify-center">
              <Award className="w-5 h-5 text-[#08070A]" />
            </div>
            <span className="text-xl font-['Playfair_Display'] font-bold">Gallaa</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <a href="#marketplace" className="hover:text-[#D4AF37] transition-colors duration-300">Marketplace</a>
            <a href="#credit" className="hover:text-[#D4AF37] transition-colors duration-300">Credit Solutions</a>
            <a href="#pricing" className="hover:text-[#D4AF37] transition-colors duration-300">Pricing</a>
            <a href="#about" className="hover:text-[#D4AF37] transition-colors duration-300">About</a>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <button className="px-4 py-2 text-[#ECE8E3] hover:text-[#D4AF37] transition-colors">
              Sign In
            </button>
            <button className="px-6 py-2 bg-gradient-to-r from-[#D4AF37] to-[#FFD777] text-[#08070A] font-medium rounded-lg hover:shadow-lg hover:shadow-[#D4AF37]/25 transition-all duration-300">
              Get Started
            </button>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </nav>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-[#08070A]/98 backdrop-blur-lg border-t border-[#ECE8E3]/10">
            <div className="px-6 py-4 space-y-4">
              <a href="#marketplace" className="block py-2 hover:text-[#D4AF37] transition-colors">Marketplace</a>
              <a href="#credit" className="block py-2 hover:text-[#D4AF37] transition-colors">Credit Solutions</a>
              <a href="#pricing" className="block py-2 hover:text-[#D4AF37] transition-colors">Pricing</a>
              <a href="#about" className="block py-2 hover:text-[#D4AF37] transition-colors">About</a>
              <div className="pt-4 border-t border-[#ECE8E3]/10 space-y-2">
                <button className="block w-full text-left py-2 hover:text-[#D4AF37] transition-colors">
                  Sign In
                </button>
                <button className="block w-full px-6 py-2 bg-gradient-to-r from-[#D4AF37] to-[#FFD777] text-[#08070A] font-medium rounded-lg text-center">
                  Get Started
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial from-[#D4AF37]/5 via-transparent to-transparent"></div>
        
        <div className="max-w-7xl mx-auto">
          <FadeInUp className="text-center max-w-4xl mx-auto">
            <div className="mb-6 flex justify-center">
              <div className="flex items-center space-x-2 px-4 py-2 bg-[#ECE8E3]/10 rounded-full border border-[#ECE8E3]/20">
                <Star className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm font-medium">Trusted by 500+ Premium Brands</span>
              </div>
            </div>

            <h1 className="text-5xl md:text-7xl font-['Playfair_Display'] font-bold leading-tight mb-6">
              {currentHero.headline}
            </h1>
            
            <p className="text-xl md:text-2xl text-[#ECE8E3]/80 leading-relaxed mb-8 max-w-3xl mx-auto">
              {currentHero.subheadline}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <button className="px-8 py-4 bg-gradient-to-r from-[#D4AF37] to-[#FFD777] text-[#08070A] font-semibold text-lg rounded-lg hover:shadow-xl hover:shadow-[#D4AF37]/30 transition-all duration-300 transform hover:-translate-y-1 min-w-48">
                {currentHero.cta}
                <ArrowRight className="inline-block w-5 h-5 ml-2" />
              </button>
              <button className="flex items-center px-8 py-4 border border-[#ECE8E3]/20 hover:border-[#D4AF37]/50 rounded-lg transition-all duration-300 min-w-48">
                <Play className="w-5 h-5 mr-2" />
                Watch Demo
              </button>
            </div>
          </FadeInUp>

          {/* Trust Badges */}
          <FadeInUp delay={200} className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm">ISO 27001 Certified</span>
            </div>
            <div className="flex items-center space-x-2">
              <Lock className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm">Bank-Grade Security</span>
            </div>
            <div className="flex items-center space-x-2">
              <Globe className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm">PCI DSS Compliant</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm">GST Integrated</span>
            </div>
          </FadeInUp>
        </div>
      </section>

      {/* Features Section */}
      <section id="marketplace" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <FadeInUp className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-['Playfair_Display'] font-bold mb-6">
              Revolutionizing Luxury B2B Trade
            </h2>
            <p className="text-xl text-[#ECE8E3]/80 max-w-3xl mx-auto">
              Experience the future of premium wholesale with our comprehensive marketplace ecosystem designed for India's luxury market.
            </p>
          </FadeInUp>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: CreditCard,
                title: "Smart Credit Solutions",
                description: "Access instant credit lines up to ₹50L based on AI-powered risk assessment and transaction history.",
                features: ["Instant approval", "Flexible terms", "Dynamic limits"]
              },
              {
                icon: Users,
                title: "Verified Network",
                description: "Connect with pre-verified luxury manufacturers and authorized distributors across India.",
                features: ["KYC verified", "Quality assured", "Performance tracked"]
              },
              {
                icon: TrendingUp,
                title: "Market Intelligence",
                description: "Make informed decisions with real-time pricing data, trend analysis, and demand forecasting.",
                features: ["Live pricing", "Trend alerts", "Demand insights"]
              },
              {
                icon: Shield,
                title: "Secure Transactions",
                description: "Bank-grade security with escrow protection, fraud prevention, and secure payment processing.",
                features: ["Escrow protected", "Fraud detection", "Encrypted payments"]
              },
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Process orders, payments, and documentation in minutes with our streamlined workflows.",
                features: ["Quick processing", "Auto documentation", "Same-day settlement"]
              },
              {
                icon: Globe,
                title: "Pan-India Reach",
                description: "Access manufacturers and retailers across all major Indian cities with integrated logistics.",
                features: ["National coverage", "Local partnerships", "Express delivery"]
              }
            ].map((feature, index) => (
              <FadeInUp key={index} delay={index * 100}>
                <div className="group p-8 bg-[#ECE8E3]/5 border border-[#ECE8E3]/10 rounded-2xl hover:border-[#D4AF37]/30 transition-all duration-500 hover:shadow-xl hover:shadow-[#D4AF37]/10 hover:-translate-y-2">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#D4AF37]/20 to-[#FFD777]/20 rounded-2xl flex items-center justify-center mb-6 group-hover:from-[#D4AF37]/30 group-hover:to-[#FFD777]/30 transition-all duration-300">
                    <feature.icon className="w-8 h-8 text-[#D4AF37]" />
                  </div>
                  <h3 className="text-xl font-['Playfair_Display'] font-semibold mb-4">{feature.title}</h3>
                  <p className="text-[#ECE8E3]/70 mb-6 leading-relaxed">{feature.description}</p>
                  <ul className="space-y-2">
                    {feature.features.map((item, idx) => (
                      <li key={idx} className="flex items-center text-sm text-[#ECE8E3]/60">
                        <CheckCircle className="w-4 h-4 text-[#D4AF37] mr-2 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeInUp>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6 bg-[#ECE8E3]/5">
        <div className="max-w-6xl mx-auto">
          <FadeInUp className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-['Playfair_Display'] font-bold mb-6">
              Transparent Pricing for Every Business
            </h2>
            <p className="text-xl text-[#ECE8E3]/80 max-w-3xl mx-auto">
              Choose the perfect plan for your business needs. All plans include our core marketplace features with different credit and transaction limits.
            </p>
          </FadeInUp>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Starter",
                price: "₹2,999",
                period: "/month",
                description: "Perfect for small retailers getting started",
                features: [
                  "Credit limit up to ₹5L",
                  "50 transactions/month",
                  "Basic analytics",
                  "Email support",
                  "Standard verification",
                  "Mobile app access"
                ],
                cta: "Start Free Trial",
                popular: false
              },
              {
                name: "Professional",
                price: "₹7,999",
                period: "/month",
                description: "Ideal for growing retail businesses",
                features: [
                  "Credit limit up to ₹25L",
                  "Unlimited transactions",
                  "Advanced analytics",
                  "Priority support",
                  "Premium verification",
                  "API access",
                  "Bulk order management",
                  "Custom payment terms"
                ],
                cta: "Most Popular",
                popular: true
              },
              {
                name: "Enterprise",
                price: "Custom",
                period: "",
                description: "For large retailers and manufacturers",
                features: [
                  "Credit limit up to ₹50L+",
                  "Unlimited everything",
                  "Custom analytics",
                  "Dedicated account manager",
                  "White-label options",
                  "Custom integrations",
                  "SLA guarantees",
                  "Volume discounts"
                ],
                cta: "Contact Sales",
                popular: false
              }
            ].map((plan, index) => (
              <FadeInUp key={index} delay={index * 100}>
                <div className={`relative p-8 rounded-2xl border ${
                  plan.popular 
                    ? 'border-[#D4AF37] bg-gradient-to-b from-[#D4AF37]/10 to-transparent' 
                    : 'border-[#ECE8E3]/20 bg-[#ECE8E3]/5'
                } transition-all duration-300 hover:border-[#D4AF37]/50 hover:-translate-y-2`}>
                  
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="px-4 py-1 bg-gradient-to-r from-[#D4AF37] to-[#FFD777] text-[#08070A] text-sm font-semibold rounded-full">
                        Most Popular
                      </span>
                    </div>
                  )}

                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-['Playfair_Display'] font-bold mb-2">{plan.name}</h3>
                    <p className="text-[#ECE8E3]/70 mb-4">{plan.description}</p>
                    <div className="mb-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-[#ECE8E3]/60">{plan.period}</span>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#D4AF37] mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-[#ECE8E3]/80">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-300 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-[#D4AF37] to-[#FFD777] text-[#08070A] hover:shadow-lg hover:shadow-[#D4AF37]/25'
                      : 'border border-[#ECE8E3]/30 hover:border-[#D4AF37] hover:text-[#D4AF37]'
                  }`}>
                    {plan.cta}
                  </button>
                </div>
              </FadeInUp>
            ))}
          </div>

          <FadeInUp delay={400} className="text-center mt-12">
            <p className="text-[#ECE8E3]/60 mb-4">
              All plans include 14-day free trial • No setup fees • Cancel anytime
            </p>
            <p className="text-sm text-[#ECE8E3]/50">
              Prices exclude GST. Volume discounts available for annual subscriptions.
            </p>
          </FadeInUp>
        </div>
      </section>

      {/* Registration CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <FadeInUp>
            <h2 className="text-4xl md:text-5xl font-['Playfair_Display'] font-bold mb-6">
              Join India's Premier Luxury Trade Network
            </h2>
            <p className="text-xl text-[#ECE8E3]/80 mb-8 leading-relaxed">
              Whether you're a manufacturer looking to expand your reach or a retailer seeking premium inventory, Gallaa provides the platform to scale your luxury business.
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
              <button className="group p-6 border border-[#ECE8E3]/20 rounded-xl hover:border-[#D4AF37]/50 transition-all duration-300 text-left">
                <div className="flex items-center mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#D4AF37]/20 to-[#FFD777]/20 rounded-lg flex items-center justify-center mr-4">
                    <Users className="w-6 h-6 text-[#D4AF37]" />
                  </div>
                  <h3 className="text-xl font-semibold">For Manufacturers</h3>
                </div>
                <p className="text-[#ECE8E3]/70 mb-4">
                  Connect with verified retailers, expand your distribution network, and access working capital solutions.
                </p>
                <span className="text-[#D4AF37] group-hover:text-[#FFD777] transition-colors">
                  Register as Manufacturer →
                </span>
              </button>

              <button className="group p-6 border border-[#ECE8E3]/20 rounded-xl hover:border-[#D4AF37]/50 transition-all duration-300 text-left">
                <div className="flex items-center mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#D4AF37]/20 to-[#FFD777]/20 rounded-lg flex items-center justify-center mr-4">
                    <TrendingUp className="w-6 h-6 text-[#D4AF37]" />
                  </div>
                  <h3 className="text-xl font-semibold">For Retailers</h3>
                </div>
                <p className="text-[#ECE8E3]/70 mb-4">
                  Source premium inventory, access credit lines, and grow your luxury retail business with confidence.
                </p>
                <span className="text-[#D4AF37] group-hover:text-[#FFD777] transition-colors">
                  Register as Retailer →
                </span>
              </button>
            </div>
          </FadeInUp>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#ECE8E3]/5 border-t border-[#ECE8E3]/10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-1">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-[#D4AF37] to-[#FFD777] rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-[#08070A]" />
                </div>
                <span className="text-xl font-['Playfair_Display'] font-bold">Gallaa</span>
              </div>
              <p className="text-[#ECE8E3]/70 mb-6">
                India's premier luxury B2B marketplace, connecting manufacturers and retailers with smart credit solutions.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-[#ECE8E3]/10 rounded-lg flex items-center justify-center hover:bg-[#D4AF37]/20 transition-colors">
                  <Globe className="w-5 h-5" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-[#ECE8E3]/70">
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Marketplace</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Credit Solutions</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Analytics</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">API</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-[#ECE8E3]/70">
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Partners</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-[#ECE8E3]/70">
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-[#D4AF37] transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-[#ECE8E3]/10 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-[#ECE8E3]/60 mb-4 md:mb-0">
              © 2025 Gallaa. All rights reserved. | CIN: U74999DL2024PTC123456
            </p>
            <div className="flex items-center space-x-6 text-sm text-[#ECE8E3]/60">
              <span>Made in India 🇮🇳</span>
              <span>•</span>
              <span>ISO 27001 Certified</span>
            </div>
          </div>
        </div>
      </footer>

      {/* A/B Test Toggle (for demo purposes - remove in production) */}
      <div className="fixed bottom-4 right-4 z-50">
        <button 
          onClick={() => setActiveTestVariant(activeTestVariant === 'A' ? 'B' : 'A')}
          className="px-4 py-2 bg-[#D4AF37] text-[#08070A] rounded-lg text-sm font-medium"
        >
          Test Variant: {activeTestVariant}
        </button>
      </div>
    </div>
  );
}

export default App;